# thomar-123mop-tables
Magic Weapon tables from u/thomar (https://twitter.com/koboldskeep) and u/123mop provided on reddit and compiled into tables by u/YourDNDPleasesMe
